.mapboxgl-ctrl-geocoder {
	min-width: 100%;
}
.mapboxgl-ctrl-geocoder, .mapboxgl-ctrl-geocoder .suggestions {
    box-shadow: none;
}
.mapboxgl-ctrl-geocoder--button svg {
    pointer-events: none;
}