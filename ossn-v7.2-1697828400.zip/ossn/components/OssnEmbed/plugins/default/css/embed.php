.ossn_embed_video {
	display: block;
}
