<div>
	<label>API</label>
    <input type="text" value="<?php echo ossn_giphy_api_key();?>" name="giphy_api_key" />
</div>
<div>
	<input type="submit" value="<?php echo ossn_print('save');?>" class="btn btn-success btn-sm" />
</div>